# Сравнение двух строк

# Запрос двух строк
s = input("s: ")
t = input("t: ")

# Сравнение двух строк
if s == t:
    print("Same")
else:
    print("Different")
