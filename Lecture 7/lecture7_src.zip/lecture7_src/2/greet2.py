# Вывод аргументов командной строки

from sys import argv

for arg in argv:
    print(arg)
