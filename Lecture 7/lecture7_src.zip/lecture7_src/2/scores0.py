# Среднее значение трёх чисел

# Элементы массива scores
scores = [72, 73, 33]

# Вывод среднего значения
average = sum(scores) / len(scores)
print(f"Average: {average}")
