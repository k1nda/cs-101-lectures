# Вывод строки заглавными символами [сразу]

before = input("Before: ")
after = before.upper()
print(f"After:  {after}")
