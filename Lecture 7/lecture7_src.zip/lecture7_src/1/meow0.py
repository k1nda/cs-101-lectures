# Пример структуры плохого кода на Python

print("meow")
print("meow")
print("meow")
