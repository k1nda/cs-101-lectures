# Вывод сетки '#' размером 3 на 3 с вложенными циклами

for i in range(3):
    for j in range(3):
        print("#", end="")
    print()
