# Простой пример с hello world на Python

print("hello, world")
