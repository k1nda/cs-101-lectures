// Простой пример с hello world на C

#include <stdio.h>

int main(void)
{
    printf("hello, world\n");
}
