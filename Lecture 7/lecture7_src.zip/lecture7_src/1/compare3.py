# Пример с условными выражением, логическими выражением на Python

from cs50 import get_int

# Запрос у пользователя двух целочисленных значений
x = get_int("What's x? ")
y = get_int("What's y? ")

# Сравнение двух целочисленных значений
if x < y:
    print("x is less than y")
elif x > y:
    print("x is greater than y")
else:
    print("x is equal to y")
