# Абстракция

def main():
    for i in range(3):
        meow()

# Описание функции meow
def meow():
    print("meow")


main()
