# Абстракция с аргументами

def main():
    meow(3)


# Описание функции meow с аргументом n
def meow(n):
    for i in range(n):
        print("meow")


main()
