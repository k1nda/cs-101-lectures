# Использование get_string, print и конкатенация строк

from cs50 import get_string

answer = get_string("What's your name? ")
print("hello, " + answer)
