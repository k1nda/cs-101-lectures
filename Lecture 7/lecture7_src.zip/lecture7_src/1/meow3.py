# Пример наилучшего использования цикла for

for i in range(3):
    print("meow")
