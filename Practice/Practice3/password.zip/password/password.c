// Проверка пароля на содержание по крайней мере одной строчной буквы, заглавной букувы, цифры и символа
// Итеракция по строке
// Практика использования заголовочного файла ctype

#include <cs50.h>
#include <stdio.h>

bool valid(string password);

int main(void)
{
    string password = get_string("Введите свой пароль: ");
    if (valid(password))
    {
        printf("Ваш пароль действителен!\n");
    }
    else
    {
        printf("В вашем пароле должна быть по крайней мере одна заглавная буква, строчная буква, цифра и символ\n");
    }
}

// TODO: Завершите описание логической функции
bool valid(string password)
{
    return false;
}
