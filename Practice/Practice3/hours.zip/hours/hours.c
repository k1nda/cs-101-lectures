#include <cs50.h>
#include <ctype.h>
#include <stdio.h>

float calc_hours(int hours[], int weeks, char output);

int main(void)
{
    int weeks = get_int("Количество недель, затраченных на изучение Introduction to Computer Science: ");
    int hours[weeks];

    for (int i = 0; i < weeks; i++)
    {
        hours[i] = get_int("В %i неделю затрачено часов: ", i);
    }

    char output;
    do
    {
        output = toupper(get_char("Введите T для вывода общего затраченного времени, A для вывода затраченного времени в среднем: "));
    }
    while (output != 'T' && output != 'A');

    printf("%.1f часов\n", calc_hours(hours, weeks, output));
}

// TODO: Описать функцию calc_hours
float calc_hours(int hours[], int weeks, char output)
{

}