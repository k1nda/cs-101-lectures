// Задание на практику работы со структурами
// Задание на практику использования алгоритмов сортировки

#include <cs50.h>
#include <stdio.h>

#define NUM_CITIES 10

typedef struct
{
    string city;
    int temp;
}
avg_temp;

avg_temp temps[NUM_CITIES];

void sort_cities(void);

int main(void)
{
    temps[0].city = "Pavlodar";
    temps[0].temp = 29;

    temps[1].city = "Astana";
    temps[1].temp = 28;

    temps[2].city = "Almaty";
    temps[2].temp = 33;

    temps[3].city = "Shymkent";
    temps[3].temp = 38;

    temps[4].city = "Karaganada";
    temps[4].temp = 29;

    temps[5].city = "Ekibastuz";
    temps[5].temp = 27;

    temps[6].city = "Uralsk";
    temps[6].temp = 30;

    temps[7].city = "Aktobe";
    temps[7].temp = 31;

    temps[8].city = "Taraz";
    temps[8].temp = 35;

    temps[9].city = "Petropavl";
    temps[9].temp = 26;

    sort_cities();

    printf("\nСредняя температура по городам в июле\n\n");

    for (int i = 0; i < NUM_CITIES; i++)
    {
        printf("%s: %i\n", temps[i].city, temps[i].temp);
    }
}

// TODO: Сортировка городов по температуре в порядке убывания
void sort_cities(void)
{
    // Здесь будет описание функции
}
