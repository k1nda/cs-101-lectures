// Среднее значение трёх чисел (hardcoded)

#include <stdio.h>

int main(void)
{
    // Элементы массива
    int score1 = 72;
    int score2 = 73;
    int score3 = 33;

    // Вывод среднего значения
    printf("Average: %f\n", (score1 + score2 + score3) / 3.0);
}
