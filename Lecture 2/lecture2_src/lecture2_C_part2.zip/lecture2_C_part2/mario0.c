// Выводит строку из 4 вопросительных знаков

#include <stdio.h>

int main(void)
{
    printf("????\n");
}
