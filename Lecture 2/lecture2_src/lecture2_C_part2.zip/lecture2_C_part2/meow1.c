#include <stdio.h>

int main(void)
{
    int i = 3;
    while (i > 3)
    {
        printf("meow\n");
        i--;
    }
}